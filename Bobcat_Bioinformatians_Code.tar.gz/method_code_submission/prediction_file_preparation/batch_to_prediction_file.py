import glob
import os
suffix = ["aa","ab","ac","ad","ae","af","ag","ah","ai","aj","ak","al","am","an","ao","ap","aq","ar","as","at","au","av","aw","ax","ay","az"]
count = 0
for line in open("TF_cell_relation.list").readlines():
	line = line.strip().split()
	TF = line[0]
	cell_list = line[1:]
	# print count,TF
	# count += 1
	# continue
	for file_index in file_index_list:
		for cell in cell_list:
			command = "python to_prediction_file.py " + TF + " " + cell + " " + file_index
			print command
			os.system(command)