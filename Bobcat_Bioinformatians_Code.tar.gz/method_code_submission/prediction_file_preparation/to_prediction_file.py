import sys
TF = sys.argv[1]
num_PC = 3
cell = sys.argv[2]
train_file_index = sys.argv[3]
copy_index = sys.argv[4] # later, I found that the output is still too big to handle. I then splitted again on some copies. The copy index is for them.
class sample:
	def __init__(self):
		self.nonred_unique = ""
		self.nonred_shared = ""
		self.epiMotif = ""
		self.dnase = ""
		self.HelT = ""
		self.Roll = ""
		self.ProT = ""
		self.MGW = ""
		self.closest_gene = ""
		# self.regulators = ""


	


train_dict={}
train_bed_file = "/home/working/my_second_drive/dream_challenge/train_region/train_regions.blacklistfiltered.bed.copy."+train_file_index+".copy." + copy_index
def parse_train_bed_file(file1):
	
	with open(file1, 'rb') as handler:
		for line in handler:
			line = line.strip().split()
			name = line[0]+":"+line[1]+"-"+line[2]
			train_dict[name] = sample()

	return 1	
parse_train_bed_file(train_bed_file)



### fimo out parsing function

def parse_spacesv(file1,motif_index,indicator):
	print file1
	# return_list = []
	# count = 0
	with open(file1, 'rb') as handler:
		for line in handler:
			# print line
			res = []
			# count += 1
			# if count % 100000 == 0:
				# print count
			line = line.strip().split()
			name = line[0]
			# print name
			if not train_dict.has_key(name):
				continue
			# res.append(name) 
			for m in motif_index:
				res.append(line[m+1])
			# return_list.append(res)
			if indicator == 1:
				train_dict[name].nonred_unique = res
			if indicator == 2:
				train_dict[name].nonred_shared = res
			if indicator == 3:
				train_dict[name].epiMotif = res
		
	return 1


### dnase  parsing function

def parse_dnase(file1):
	cell_type = file1.split("/")[-1]
	cell_type = cell_type.split(".")[-2]
	if not cell_type == cell:
		return 1
	# return_list = []
	print file1
	with open(file1, 'rb') as handler:
		for line in handler:
		
			line = line.strip().split(",")
			name = line[0]
			if not train_dict.has_key(name):
				continue
			# res = [] ### this is important, this is bug for dnase and shape
			train_dict[name].dnase = [line[1],line[2]]
			# res.append(name)
			# res.append(cell_type)
			# for i in range(1,4):
			# res.append(line[2])
			# return_list.append(res)
	return 1

### closest gene expression  parsing function

def parse_closest(file1):
	cell_type = file1.split("/")[-1]
	cell_type = cell_type.split(".")[-2]
	if not cell_type == cell:
		return 1
	# return_list = []
	print file1
	with open(file1, 'rb') as handler:
		for line in handler:
		
			line = line.strip().split()
			name = line[0]
			if not train_dict.has_key(name):
				continue
			# res = [] ### this is important, this is bug for dnase and shape
			train_dict[name].closest_gene = [line[1]]
			# res.append(name)
			# res.append(cell_type)
			# for i in range(1,4):
			# res.append(line[1])
			# return_list.append(res)
	return 1

### TF regulators  parsing function
def parse_regulators(regulators):
	regulators_dict = {}
	with open(regulators) as f:
		for line in f:
			line = line.strip().split()
			cell = line[0].split("_")[-1]
			if cell == "cell":
				cell = "induced_pluripotent_stem_cell"
			regulators_dict[cell] = line[1:]		
	return regulators_dict
	
###  Shape parsing function

def parse_shape(file1):
	shape_type = file1.split("/")[-1]
	shape_type = shape_type.split(".")[-2]
	# return_list = []
	print file1
	with open(file1, 'rb') as handler:
		for line in handler:
			line = line.strip().split(",")
			name = line[0]
			if not train_dict.has_key(name):
				continue
			# res=[]
			# res.append(name)
			# res.append(shape_type)
			if shape_type == "HelT":
				train_dict[name].HelT = [line[1],line[2]]
			if shape_type == "Roll":
				train_dict[name].Roll = [line[1],line[2]]
			if shape_type == "ProT":
				train_dict[name].ProT = [line[1],line[2]]
			if shape_type == "MGW":
				train_dict[name].MGW = [line[1],line[2]]
			# for i in range(1,4):
			# res.append(line[2])
			# return_list.append(res)
	return 1



### gene expression ###

gene_expression = "/home/working/dream_encode/gene_expression/pca_output_matrix.csv"

def readGenePcaFile(pcaFile):
	gene_PCs = {}
	file_handle = open(pcaFile)
	lines = file_handle.readlines()
	for line in lines[1:]:
		line = line.split(",")
		current_cell = line[0].split(".")[0]
		# print line
		# print current_cell
		if gene_PCs.has_key(current_cell):
			# print gene_PCs[current_cell]
			for i in range(1,num_PC+1):
				
				gene_PCs[current_cell][i-1] =(gene_PCs[current_cell][i-1]+float(line[i]))/2
				# b = float(line[i])
				# gene_PCs[current_cell] = (a+b)/2
		else:
			gene_PCs[current_cell] = []
			for i in range(1,num_PC+1):
				gene_PCs[current_cell].append(float(line[i]))
				# gene_PCs[current_cell].append(ast.literal_eval(line[i]))
	file_handle.close()
	return gene_PCs
	

def parse_motif_list(file):
	motif_list = []
	with open(file) as f:
		for line in f:
			line = line.strip()
			if not line in motif_list:
				motif_list.append(line)
	return motif_list

def get_motif_index(all,selected):
	motif_index = []
	for m in selected:
		try:
			motif_index.append(all.index(m))
		except:
			continue
	return motif_index
	

def all_motif_features(file1):
	motif_list = []
	with open(file1, 'rb') as handler:
		for line in handler:
			if "MOTIF" in line:
				line = line.strip().split()
				if len(line[1]) > 100:
					motif_list.append(line[1][:100])
				else:
					motif_list.append(line[1])
	return motif_list



gene_PC = readGenePcaFile(gene_expression)
# train_dict
# important variable ABOVE	
import glob

######### nonred_unique features #####################
selected_motif_list = parse_motif_list("/home/working/my_second_drive/dream_challenge/TF_motif_list/"+TF+".nonred.top120.motif.list")
all_motif_list = all_motif_features("/home/working/my_second_drive/dream_challenge/train_region_nonred_RF_selected_mapping/RF_nonred_unique.pwm")
motif_index = get_motif_index(all_motif_list,selected_motif_list)
spacesv_list = glob.glob("/home/working/my_second_drive/dream_challenge/train_region_nonred_RF_selected_mapping/train_regions.blacklistfiltered.bed.copy."+train_file_index+".nonred_1715.RF_selected.unique.spacesv")
map(lambda x:parse_spacesv(x,motif_index,1),spacesv_list)

######### nonred_shared features #####################


all_motif_list = parse_motif_list("/home/working/my_second_drive/dream_challenge/TF_motif_list/RF_prefilter_nonred_shared.list")
motif_index = get_motif_index(all_motif_list,selected_motif_list)
spacesv_list = glob.glob("/home/working/my_second_drive/dream_challenge/train_region_nonred_RF_selected_mapping/train_regions.blacklistfiltered.bed.copy."+train_file_index+".nonred_1715.RF_selected.shared.spacesv")
map(lambda x:parse_spacesv(x,motif_index,2),spacesv_list)


######### epiMotif features #####################

selected_motif_list = parse_motif_list("/home/working/my_second_drive/dream_challenge/TF_motif_list/"+TF+".epiMotif.top40.motif.list")
all_motif_list = parse_motif_list("/home/working/my_second_drive/dream_challenge/TF_motif_list/epimotifs.commbined.top.motifs.list")
motif_index = get_motif_index(all_motif_list,selected_motif_list)
spacesv_list = glob.glob("/home/working/my_second_drive/dream_challenge/train_region_epiMotif_RF_selected_mapping/train_regions.blacklistfiltered.bed.copy."+train_file_index+".epiMotifs_2034.RF_selected.spacesv")
map(lambda x:parse_spacesv(x,motif_index,3),spacesv_list)






######### dnase features #####################
dnase_file_list = glob.glob("/home/working/my_second_drive/dream_challenge/train_region_Dnase/*."+train_file_index+"."+cell+".csv")

map(lambda x:parse_dnase(x),dnase_file_list)


######### shape features #####################
shape_out_list = glob.glob("/home/working/my_second_drive/dream_challenge/train_region_DNAshape/*."+train_file_index+".*.csv")

map(lambda x:parse_shape(x),shape_out_list)


######### closest gene expression features #####################
closest_file_list = glob.glob("/home/working/my_second_drive/dream_challenge/genome_annotation/*"+train_file_index+".closest.*.tsv")

map(lambda x:parse_closest(x),closest_file_list)


######### regulators gene expression features #####################
regulators_file = "/home/working/my_second_drive/dream_challenge/TF_regulators/" + TF
regulator_dict = parse_regulators(regulators_file)


######### print file #####################

import numpy as np
print "printing file"


out_file_name = TF+"." +cell + "."+ train_file_index + "."+copy_index+".csv"
out_file = open(out_file_name,"wb")
single_cell_TF_list = ["FOXA1","FOXA2","HNF4A","NANOG"]
for name in train_dict:
	
	
	
	
	gene_expression_values = gene_PC[cell]
	# mean_gene_PC = np.mean(gene_expression_values)
	regulator_expression_values = regulator_dict[cell]
	mean_regulators = np.mean(map(lambda x:float(x),regulator_expression_values))
	motif_array = train_dict[name].nonred_unique + train_dict[name].nonred_shared + train_dict[name].epiMotif
	mean_motif_value = np.mean(map(lambda x:float(x),motif_array))
	
	
	motif_dnase = mean_motif_value*float(train_dict[name].dnase[1])
	motif_HelT = mean_motif_value*float(train_dict[name].HelT[1])
	motif_Roll = mean_motif_value*float(train_dict[name].Roll[1])
	motif_ProT = mean_motif_value*float(train_dict[name].ProT[1])
	motif_MGW = mean_motif_value*float(train_dict[name].MGW[1])
	motif_ePC = map(lambda x: x*mean_motif_value,gene_expression_values)
	motif_close = mean_motif_value*float(train_dict[name].closest_gene[0]) 
	motif_regulators = mean_motif_value*mean_regulators
	
	composite_values = [motif_dnase,motif_HelT,motif_Roll,motif_ProT,motif_MGW,motif_close,motif_regulators] + motif_ePC

	if not TF in single_cell_TF_list:
		out_line = [name]+ motif_array +  train_dict[name].HelT + train_dict[name].Roll + train_dict[name].MGW + train_dict[name].ProT + train_dict[name].dnase + train_dict[name].closest_gene + map(lambda x:str(x),composite_values) + map(lambda x:str(x),gene_expression_values) + regulator_expression_values
	else:
		out_line = [name]+ motif_array +  train_dict[name].HelT + train_dict[name].Roll + train_dict[name].MGW + train_dict[name].ProT + train_dict[name].dnase + train_dict[name].closest_gene + map(lambda x:str(x),composite_values)
	
	print >>out_file,",".join(out_line)



