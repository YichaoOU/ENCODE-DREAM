import sys
import gzip
import glob
TF = sys.argv[1]
spacesv_file_list = glob.glob("/home/working/my_second_drive/dream_challenge/nonred_spacesv/train_regions.blacklistfiltered.bed.copy.ae.nonredundant_1715.split.*.spacesv.gz")
# motif_type = sys.argv[2]
# motif_index = sys.argv[3]
class sample:
	def __init__(self):
		self.motif = []
		self.label = "0"


	


train_dict={}
train_bed_file = "/home/working/my_second_drive/dream_challenge/train_labels_subsampled/TF.conference_round_nonred.sampled.label.tsv"

train_bed_file = train_bed_file.replace("TF",TF)
def parse_train_bed_file(file1):
	
	with open(file1, 'rb') as handler:
		for line in handler:
			line = line.strip().split()
			name = line[0]+":"+line[1]+"-"+line[2]
			train_dict[name] = sample()
			if line[-1] == "B":
				train_dict[name].label = "1"

	return 1	
parse_train_bed_file(train_bed_file)

######### spacesv file #####################

def parse_spacesv_file(file):
	count = 0
	start_count = 1487856
	end_count = 3537572
	with gzip.open(file,"rt") as f:
		for line in f:
			count += 1
			if count > end_count:
				return 1
			if count >= start_count and count <= end_count:
				line = line.strip().split()
				name = line[0]
				motif = line[1:]
				try:
					train_dict[name].motif += motif
				except:
					continue
	return 1		

for i in range(35):
	spacesv_file = glob.glob("/home/working/my_second_drive/dream_challenge/nonred_spacesv/train_regions.blacklistfiltered.bed.copy.ae.*.split."+str(i)+".spacesv.gz")
	# print "/home/working/my_second_drive/dream_challenge/nonred_spacesv/train_regions.blacklistfiltered.bed.copy.ae.*.split."+str(i)+".spacesv.gz"
	print i
	for file1 in spacesv_file:
		# print file1
		parse_spacesv_file(file1)


######### print file #####################


print "printing file"
out_file_name = TF+".conference_round.nonred_1715.features.csv"
out_file = open(out_file_name,"wb")
for name in train_dict:
		

	
	out_line = train_dict[name].motif+ [train_dict[name].label]
	
	print >>out_file,",".join(out_line)



