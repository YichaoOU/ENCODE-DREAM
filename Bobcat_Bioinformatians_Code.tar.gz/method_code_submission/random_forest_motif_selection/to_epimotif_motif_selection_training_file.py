import sys
import gzip
import glob
TF = sys.argv[1]
spacesv_file_list = glob.glob("/home/working/my_second_drive/dream_challenge/train_region/spacesv/train_regions.blacklistfiltered.bed.copy.ad.epiMotifs_2034.split.*.spacesv.gz")
# motif_type = sys.argv[2]
# motif_index = sys.argv[3]
class sample:
	def __init__(self):
		self.motif = []
		self.label = "0"


	


train_dict={}
train_bed_file = "/home/working/my_second_drive/dream_challenge/train_labels_subsampled/TF.conference_round.sampled.label.tsv"

train_bed_file = train_bed_file.replace("TF",TF)
def parse_train_bed_file(file1):
	
	with open(file1, 'rb') as handler:
		for line in handler:
			line = line.strip().split()
			name = line[0]+":"+line[1]+"-"+line[2]
			train_dict[name] = sample()
			if line[-1] == "B":
				train_dict[name].label = "1"

	return 1	
parse_train_bed_file(train_bed_file)

######### spacesv file #####################

def parse_spacesv_file(file):
	count = 0
	start_count = 1908133
	end_count = 4211488
	with gzip.open(file,"rt") as f:
		for line in f:
			count += 1
			if count >= start_count and count <= end_count:
				line = line.strip().split()
				name = line[0]
				motif = line[1:]
				try:
					train_dict[name].motif += motif
				except:
					continue
	return 1		

for i in range(1,103):
	spacesv_file = "/home/working/my_second_drive/dream_challenge/train_region/spacesv/train_regions.blacklistfiltered.bed.copy.ad.epiMotifs_2034.split."+str(i)+".spacesv.gz"
	print i
	parse_spacesv_file(spacesv_file)


######### print file #####################


print "printing file"
out_file_name = TF+".conference_round.epiMotifs.features.csv"
out_file = open(out_file_name,"wb")
for name in train_dict:
		
	# print train_dict[name].nonred_others_split_1
	# print train_dict[name].nonred_others_split_2
	# print train_dict[name].nonred_others_split_3
	# print train_dict[name].nonred_others_split_4
	# print train_dict[name].nonred_others_split_5
	# print train_dict[name].nonred_others_split_6
	# print train_dict[name].nonred_others_split_7
	# print train_dict[name].nonred_27_32
	# print train_dict[name].epiMotif_1_30
	# print train_dict[name].epiMotif_31_70_copy1
	# print train_dict[name].epiMotif_31_70_copy2
	# print train_dict[name].epiMotif_71_102
	# print train_dict[name].HelT
	# print train_dict[name].Roll
	# print train_dict[name].MGW
	# print train_dict[name].ProT
	# print train_dict[name].dnase
	# print map(lambda x:str(x),gene_expression_values)
	# print train_dict[name].closest_gene
	# print regulator_expression_values
	# print train_dict[name].label
	
	out_line = train_dict[name].motif+ [train_dict[name].label]
	
	print >>out_file,",".join(out_line)



