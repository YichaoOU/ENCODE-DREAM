import glob
import sys

# all_motif_list = "../epiMotifs/epiMotifs_2034.motif.list"
all_motif_list = "nonredundant_1715_revised.motif.list"

# TF_motif_index = glob.glob("*.feature.ranking1")
TF_motif_index = glob.glob("*.feature.ranking2")

motif_list = open(all_motif_list).readlines()

top_number = 120

for TF_motif in TF_motif_index:
	count = 0
	TF = TF_motif.split(".")[0]
	# out = open(TF+".epiMotif.top"+str(top_number) + ".motif.list","wb")
	out = open(TF+".nonred.top"+str(top_number) + ".motif.list","wb")
	with open(TF_motif) as f:
		for line in f:
			count += 1
			if count > top_number:
				break
			line = line.strip().split()
			print >>out,motif_list[int(line[0])].strip()
	out.close()




















