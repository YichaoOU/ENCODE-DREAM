import numpy as np
import pandas as pd
import sys
from sklearn.ensemble import RandomForestClassifier as RFC
from sklearn import svm
from sklearn import datasets
from sklearn.cross_validation import StratifiedKFold
from sklearn.cross_validation import KFold
from sklearn.grid_search import GridSearchCV
from sklearn.metrics import classification_report
from sklearn.metrics import precision_score
from sklearn.metrics import accuracy_score
from sklearn.metrics import recall_score
from sklearn.metrics import roc_curve
from sklearn.metrics import auc
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier as DTC
from sklearn.metrics import average_precision_score
from sklearn.externals import joblib
import glob
file = sys.argv[1]
TF = file.split(".")[0]
print TF
data = pd.read_csv(file,delimiter = ",")
print "finish reading data"
X_train = data.values[:,:-1]

Y_train = list(data.values[:,-1])

print "begin classification"
rf_clf = RFC(n_estimators=150,n_jobs=-1,class_weight ={0:0.01,1:0.99})
# rf_clf.fit(X_train, Y_train)
rf_clf.fit(X_train, Y_train)


# rf_clf = joblib.load(model_file)

features=range(3000)


hash={}
count = 0
out = open(TF+".feature.ranking2","wb")	
for i in rf_clf.feature_importances_:
	#print i
	hash[count]=[i,features[count],i]
	count+=1
his_list = sorted(hash,key=lambda x:hash[x][2],reverse=True)
# print "feature rank \t square of weight value"
for pos in his_list:
	print >>out,hash[pos][1],"\t",hash[pos][2]
	







