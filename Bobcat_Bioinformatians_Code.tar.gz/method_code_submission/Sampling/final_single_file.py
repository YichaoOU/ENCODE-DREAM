

import random
import sys
tsv_file = sys.argv[1]
# single_cell_TF_list = ["FOXA1","FOXA2","HNF4A","NANOG","E2F1"]

percentage_of_unbound = 0.055 #"FOXA1","FOXA2","HNF4A","NANOG","E2F1"

percentage_of_bound = 1.0





import re

def process_line(line):
	line = line.strip().split("\t")
	chr = line[0]
	start = line[1]
	end = line[2]
	for i in range(number_cell_lines):
		cell = cell_lines[i]
		# print cell
		info = line[3+i]
		if info == "B":
			# 100% selection
			output_list = []
			output_list.append(chr)
			output_list.append(start)
			output_list.append(end)
			output_list.append(cell)
			output_list.append("B")
			output_line = "\t".join(output_list)
			print >>sampled_file,output_line
			# bound_train_test_files(training_file,testing_file,output_line)
			# return output_line
		if info == "U":
			# print line
			last_line_label = last_line.strip().split()[3+i]
			try:
				next_line_label = next_line.strip().split()[3+i]
			except:
				next_line_label = "U"
			if last_line_label == "B" or next_line_label == "B":
				cut_off = 1
			else:
				cut_off = percentage_of_unbound
			prob = random.uniform(0,1)
			# print prob
			# print cut_off
			if prob > cut_off:
				continue
			output_list = []
			output_list.append(chr)
			output_list.append(start)
			output_list.append(end)
			output_list.append(cell)
			output_list.append("U")
			output_line = "\t".join(output_list)
			print >>sampled_file,output_line
	return 1

TF_name = tsv_file.split(".")[0]
# print TF_name
out_file = TF_name+".final_single_cell.sampled.label.tsv"
out_file = "/home/working/my_second_drive/dream_challenge/final_train_labels_subsample/" + out_file
# out_file = "/home/working/my_second_drive/dream_challenge/train_labels_subsampled/" + out_file
sampled_file = open(out_file,"wb")
count = 0
last_line = ""
current_line = ""
next_line = ""
with open(tsv_file) as f:
	for line in f:
		if count == 0:
			
			line = line.strip().split()
			cell_lines = line[3:]
			number_cell_lines = len(cell_lines)
		elif count == 1:
			last_line = line
		elif count == 2:
			current_line = line
		elif count == 3:
			next_line = line
		else:
			process_line(current_line)
			last_line = current_line
			current_line = next_line
			next_line = line
		count += 1
		if count % 100000 == 0:
			print count







