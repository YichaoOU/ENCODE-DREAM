
import glob
import sys

gene_expression_tsv_dir = sys.argv[1]
tsv_file_list = glob.glob(gene_expression_tsv_dir+"/gene_expression.*.tsv")

# print tsv_file_list



# header
header_file = open(tsv_file_list[0]).readlines()

header = []
for gene in header_file[1:]:
	gene = gene.split("\t")[0]
	header.append(gene)

header.append("Class")

print ",".join(header)

# END print header

# print content


for tsv_file in tsv_file_list:
	temp = tsv_file.split(".")
	cell_name = temp[-3]+"."+temp[-2]
	TPM_list = []
	for line in open(tsv_file).readlines()[1:]:
		TPM = line.split("\t")[5]
		TPM_list.append(TPM)
	TPM_list.append(cell_name)
	print ",".join(TPM_list)












