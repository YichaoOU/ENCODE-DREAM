cell_lines = ["HepG2","H1-hESC","MCF-7","SK-N-SH","HCT116","Panc1","induced_pluripotent_stem_cell","PC-3","liver","IMR90","K562","GM12878","HeLa-S3","A549"]
import glob
import pickle
import sys
f = open('gene_expression_dict.pckl', 'rb')
gene_expression_dict = pickle.load(f)
f.close()
def parse_TF_regulators(file):
	TF_regulators = {}
	with open(file) as f:
		for line in f:
			line = line.strip().split(":")
			regulators = line[1].split(",")
			# print regulators
			TF_regulators[line[0]] = regulators

	return TF_regulators


TF_regulators = parse_TF_regulators("TF_regulators_finalround.list")

def parse_gene_id_gene_name_mapping(file):
	mapping = {}
	with open(file) as f:
		for line in f:
			line = line.strip().split()
			key = line[0]
			value = line[1]
			if mapping.has_key(key):
				mapping[key].append(value)
			else:
				mapping[key] = [value]
			

	return mapping

mapping = parse_gene_id_gene_name_mapping(sys.argv[1])

for tf in TF_regulators:
	out = open(tf,"wb")
	for cell in cell_lines:
		row = [tf+"_"+cell]
		for regulators in TF_regulators[tf]:
			for gene_id in mapping[regulators]:
				if gene_expression_dict.has_key(gene_id):
					value1 = float(gene_expression_dict[gene_id][cell][0])
					value2 = float(gene_expression_dict[gene_id][cell][1])
					mean = str((value1+value2)/2)
					row.append(mean)
					break
		print >>out,"\t".join(row)	


