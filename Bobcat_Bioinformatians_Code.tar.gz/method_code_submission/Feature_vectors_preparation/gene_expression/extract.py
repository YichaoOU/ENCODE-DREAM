

import sys
for line in open(sys.argv[1]).readlines():
	line = line.strip().split()
	chr = line[0]
	start = line[3]
	end = line[4]
	temp = line[9]
	gene_id = temp.split('"')[1]
	print "\t".join([chr,start,end,gene_id])
	

















