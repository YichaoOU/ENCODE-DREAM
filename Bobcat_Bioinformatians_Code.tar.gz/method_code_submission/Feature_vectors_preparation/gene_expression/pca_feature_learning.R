
rangescale <- function(X) {

	Xmax <- apply(X, 2, max)
	Xscaled = scale(X, scale=Xmax, center=T)

	return(Xscaled)
}
library('scales')

df=read.table("pca_input_matrix.csv",sep=",",header=T)
df = df[sapply(df, function(x) length(unique(na.omit(x)))) > 1]
size_df = dim(df)

data = data.matrix(df[,1:(size_df[2]-1)])
data = rangescale(data)

pca = prcomp(data)

write.csv(pca$x,"pca_output_matrix.csv")
