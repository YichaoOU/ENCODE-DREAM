
import glob
import pickle
bed_file_list = glob.glob("*.closest") 
# print bed_file_list
# exit()
f = open('gene_expression_dict.pckl', 'rb')
gene_expression_dict = pickle.load(f)
f.close()
cell_lines = ["HepG2","H1-hESC","MCF-7","SK-N-SH","HCT116","Panc1","induced_pluripotent_stem_cell","PC-3","liver","IMR90","K562","GM12878","HeLa-S3","A549"]
def to_new_tsv(bed):
	print bed
	# file_index = bed.split(".")[-2]
	out_handler_dict = {}
	for cell in cell_lines:
		out_handler_dict[cell] = open(bed+"."+cell+".tsv","wb")
	with open(bed) as f:
		for line in f:
			line = line.split()
			chr = line[0]
			start = line[1]
			end = line[2]
			name = chr+":"+start+"-"+end
			gene_id = line[-2]
			for cell in gene_expression_dict[gene_id]:
				value1 = float(gene_expression_dict[gene_id][cell][0])
				value2 = float(gene_expression_dict[gene_id][cell][1])
				mean = str((value1+value2)/2)
				print >>out_handler_dict[cell],name,mean
	for cell in cell_lines:
		out_handler_dict[cell].close()
	return 1	



map(lambda x:to_new_tsv(x),bed_file_list)














