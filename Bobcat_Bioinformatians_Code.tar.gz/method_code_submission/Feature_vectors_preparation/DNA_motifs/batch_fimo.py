

import os
import glob
import sys
a = int(sys.argv[1])
b = int(sys.argv[2])
motif_database = sys.argv[3] # motif type: either epiMotifs_2034 or nonredundant_1715
motif_file_index = ""
motif_dir = sys.argv[4]
fasta_dir = sys.argv[5]
# motif_all_index_range = range(a,b)
# print motif_all_index_range
# command = "fimo --no-qvalue --text " + motif + " " + fasta + " > " + out
motif_list = glob.glob(motif_dir+"/"+motif_database+".split.*.pwm")
fasta_list = glob.glob(fasta_dir+"/*merged*.fa")
for fasta in fasta_list:
	for motif in motif_list:
		motif_file_index = motif.split("/")[-1]
		motif_file_index = motif_file_index.split(".")[-2]
		motif_file_index_int = int(motif_file_index)
		# print motif_file_index_int
		if not motif_file_index_int in motif_all_index_range:
			continue
		out = fasta + "." + motif_database + "." + motif_file_index + ".fimo.out"
		cut = out + ".cut"
		command = "fimo --no-qvalue --text " + motif + " " + fasta + " > " + out
		print command
		os.system(command)
		command = "cut -f 1,2,3,4,6 " + out + " > " + cut
		print command
		os.system(command)
		os.system("rm "+out)


