import sys
# from itertools import izip_longest
window_size = 200
motif_list = []
def all_motif_features():
	file1 = sys.argv[1]
	with open(file1, 'rb') as handler:
		for line in handler:
			if "MOTIF" in line:
				line = line.strip().split()
				if len(line[1]) > 100:
					motif_list.append(line[1][:100])
				else:
					motif_list.append(line[1])

all_motif_features()
total_number_motif = len(motif_list)


fimo_out_file = sys.argv[2]
global bed_dict
bed_dict={}
bed_array = []
# chr_list = []

train_bed_file = sys.argv[3]

def all_bed_to_dict():
	with open(train_bed_file, 'rb') as handler:
		for line in handler:
			line = line.strip().split()
			# if not line[0] in chr_list:
				# chr_list.append(line[0])
			name = line[0]+":"+line[1]+"-"+line[2]
			bed_array.append(name)
			bed_dict[name] = [0]*total_number_motif

all_bed_to_dict()

from multiprocessing import Pool
from multiprocessing import Process, Queue
def get_start(x,y):
	min_start = x-window_size
	# print x
	prefix = int(min_start/100)
	# print prefix
	
	max_start = y
	# print y
	possible_number_list = []
	for i in range(7):
		current = prefix*100+i*50
		if current <= min_start:
			continue
		if current >= max_start:
			continue
		possible_number_list.append(current)
	# print possible_number_list,x,y
	return possible_number_list

def get_out_line(i):
	line = next_n_lines[i]
	if line == "None":
		return 1
	try:
		line = line.strip().split()
		
	except:
		return 1
	# if i%10000 == 0:
		# print i
	motif_name = line[0]
	pos = motif_list.index(motif_name)
	seq_name = line[1]
	match_start = int(line[2])
	match_end = int(line[3])
	score = float(line[4])
	# print score
	temp1 = seq_name.split(":")
	chr = temp1[0]
	# if not chr in chr_list:
		# return 1
	temp2 = temp1[1].split("-")
	start = int(temp2[0])
	true_start = start + match_start
	true_end = start + match_end
	possible_number_list = get_start(true_start,true_end)
	# print possible_number_list
	return_list = []
	for x in possible_number_list:
		y = x+window_size
		name = chr+":"+str(x)+"-"+str(y)
		return_list.append([name,pos,score])		
	return return_list

def get_out_line2(line):
	line = line.strip().split()
	# print line
	motif_name = line[0]
	pos = motif_list.index(motif_name)
	seq_name = line[1]
	match_start = int(line[2])
	match_end = int(line[3])
	score = float(line[4])
	# print score
	temp1 = seq_name.split(":")
	chr = temp1[0]
	# if not chr in chr_list:
		# return 1
	# print "asd"
	temp2 = temp1[1].split("-")
	start = int(temp2[0])
	true_start = start + match_start
	true_end = start + match_end
	possible_number_list = get_start(true_start,true_end)
	# print possible_number_list
	return_list = []
	for x in possible_number_list:
		y = x+window_size
		name = chr+":"+str(x)+"-"+str(y)
		return_list.append([name,pos,score])		
	return return_list
	
	
# print "start mapping"
count = 0
with open(fimo_out_file,"rb") as f:
	for line in f:
		if count == 0:
			count += 1
			continue
		else:
			r = get_out_line2(line)
		count += 1
		if r == 1:
			continue
		for elem in r:
			if bed_dict.has_key(elem[0]):
				if bed_dict[elem[0]][elem[1]] < elem[2]:
					bed_dict[elem[0]][elem[1]]=elem[2]

name_suffix = sys.argv[4]
output_file = train_bed_file.split("/")[-1]+"."+name_suffix
# output_file = "train_regions.blacklistfiltered.bed.copy.aj.top5union.csv"
f = open(output_file,"wb")
for b in bed_array:
	scores = bed_dict[b]
	scores = map(lambda x:str(x),scores)
	print >>f," ".join([b]+scores)





