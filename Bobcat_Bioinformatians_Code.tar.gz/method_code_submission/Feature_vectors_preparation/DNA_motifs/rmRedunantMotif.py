#!/usr/bin/python

#
# author : prashant kuntala
# date   : 9-12-16
#

#------------------------------------------------------------------------------------------
#	This script runs tomtom to find the similar motifs and remove those that are similar p-value threshold 0.0001 (ie. remove motifs less than pthreshold). 
# The seed motif is randomly picked each iteration to compare with the rest of the motifs.

#-------------------------------------------------------------------------------------------

import re
import os
import sys,shutil,csv
from random import randint
import subprocess

pwmheader = "MEME version 4.4 \n\
ALPHABET= ACGT \n\
strands: + - \n\
Background letter frequencies: \n\
A 0.25000 C 0.25000 G 0.25000 T 0.25000 \n\n"


redundantMotifs = list() # stores a list of redundant motifs
dirpath = os.getcwd() # path to a directory where you want to create the combined file
allMotifFile = os.path.expanduser(dirpath+"/all_motifs_5_DB.combined.pwm") #path to file consisting all pwms
dirpath = os.path.expanduser(dirpath+"/Dreamreq2")

def generateIndPwmFiles() :
	
	"""
	Function to create individual pwm files from the All Motifs file
	"""
	if(os.path.exists(dirpath+"/indPwmfiles")) :
		print "indPwfiles folder already created "
	else :		
		mainFile = open(allMotifFile,"r")
		#os.mkdir(dirpath)
		#print mainFile
		os.mkdir(dirpath+"/indPwmfiles")

		filename = "deleteme" # This is needed because while reading the first line there is not regex match.
		for line in mainFile :
			if re.search("MOTIF*",line):
				name = line[6:24]			
				filename = dirpath+"/indPwmfiles/"+name.strip()+".pwm"
				temp = open(filename,"w")
				temp.write(pwmheader)
				temp.close()
				print filename
			temp = open(filename,"a")	
			temp.write(line)
			temp.close()
		mainFile.close()
		os.remove(os.getcwd()+"/deleteme")
	return 
 

def moveSeeds() :

	"""
	This fuction selects a random seed motif and moves the seed Motifs into a folder called Seeds and generates a common pwm for all those motifs.
	"""

	indMotifList=os.listdir(dirpath+"/indPwmfiles")
	num = randint(0,(len(indMotifList)-1))
	print " length of indMotifList : "+str(len(indMotifList))+"num value : " +str(num)
	source = dirpath+"/indPwmfiles/" + indMotifList[num]
	destination = dirpath+"/Seeds/" + indMotifList[num]
	#print source + "\t" + destination + "\n"
	shutil.move(source,destination)
	
	return


def compareMotifs(k) :

	"""
	This function creates the database.pwm [ which has pwm's of all motifs except the seeds ], creates the make file 
	"""
	filelist = os.listdir(dirpath+"/indPwmfiles")
	filelist.sort()	
	print len(filelist)	
	combinedFile = open(dirpath+"/combinedpwm/database.pwm",'w')
	combinedFile.write(pwmheader)
	# iterating through all the files in the filelist
	for myfile in filelist :
		openfile = open(dirpath+"/indPwmfiles/"+myfile,'r')
		filecontents = openfile.readlines()
		for line in range(6,len(filecontents)):
			combinedFile.write(filecontents[line])
		openfile.close()
	combinedFile.close()
	
	"""
		creates the make file in that particular directory itself.
	"""

	path_single = dirpath+"/Seeds/" # path to the folder that has single pwms
	path_combined = dirpath+"/combinedpwm/database.pwm" # path to the folder that has the all the combined pwm.

	single = os.listdir(path_single)	
	os.mkdir(dirpath+"/Results/comparision_Results_"+str(k))
	single.sort()	
	mfile = open(dirpath+"/Results/comparision_Results_"+str(k)+"/Makefile" ,"w")
	string = "all : \n"
	mfile.write(string)
	for i in range(0,len(single)) :
		foldername = dirpath+"/Results/comparision_Results_"+str(k)+"/TTc_" + single[i] #TTC means tomtomcomparision folder	
		string = "	tomtom  -o "+ foldername[:-4] +" "+ path_single+single[i] + " "+path_combined+"\n"
		mfile.write(string)
	return


def createFolders():
	"""
	This function creates the necessary folders before calling the other functions dependent on it , if the folders already exist then , it skips creating the folders.
	"""
	if(os.path.exists(dirpath+"/Seeds") and os.path.exists(dirpath+"/combinedpwm") and os.path.exists(dirpath+"/Results") and os.path.exists(dirpath+"/Redundant")) :
		print "Seeds folder already created "
		print "combinedpwm folder already created "
	else :		
		os.mkdir(dirpath+"/Seeds") # creating the destination folder
		os.mkdir(dirpath+"/combinedpwm")
		os.mkdir(dirpath+"/Results")
		os.mkdir(dirpath+"/Redundant")

def callMake(j) :
	"""
	This function executes the makefile created for running tomtom and runs tomtom to compare seeds against the database.pwm file	
	"""
	makepath = dirpath+"/Results/comparision_Results_"+str(j)+"/"
	p = subprocess.Popen(["make"],stdout=subprocess.PIPE,cwd=makepath)
	for line in p.stdout:
	    print(line.decode().strip())
	return

def removeSeeds():

	"""
	This function removes the seeds that were copied in each iteration.
	"""
	if(os.path.exists(dirpath+"/Seeds")):
		contents = os.listdir(dirpath+"/Seeds")
		if(len(contents) != 0):
			destination = dirpath+"/indPwmfiles/" + contents[0]
			source = dirpath+"/Seeds/" + contents[0]
			#print source + "\t" + destination + "\n"
			shutil.move(source,destination)
			""" 
			# uncomment to debug to check whether the file is deleted
			for l in contents:
				if(os.path.exists(dirpath+"/Seeds"+l)):
					print "not deleted"
				else:
					print "deleted"
			"""	
	return


def removeThreshold(pvalue) :
	"""
	this function removes the pvalues that are greater than tpv(threshold) given by the user and returns it.
	"""
	temp = [] # list of pvalues after removing the vales greater than the tpv (threshold)
	
	for k in pvalue :
		k = format(float(k),'.5f') # used to convert the values 4.06948e-05 to decimal equivalent.
		if (float(k) <= 0.0001) :
			
			#print "  " + k
			temp.append(k)
			#print format(7.04408e-06, '.5f')

	#print count
	
	return temp

def removeMatches(matches, temp):
	"""
	This function takes the list of matches and pvalue from the tomtom file and removes the motif matches based on the pvalues and returns the resulting list of motif matches.
	"""
	m = []
	t = list(temp)
	
	for k in t :		
		ind = t.index(k) #finding the index of particular pvalue
		val = matches[ind] # retrieve the motif match
		m.append(val)
		t[ind] = 0	
			
	return m

def refineTomtom(iteration):

	"""
	This function opens each tomtom file and processes it to generate the list of motifs that are less that p-value threshold 0.0001 and returns it.
	"""
	
	path = os.path.expanduser(dirpath+"/Results/comparision_Results_"+str(iteration))
	filelist = os.listdir(path)
	matches = [] # list that stores the motif matches
	pvalue = [] # list that stores the pvalues of the motif matches.
	temp = [] # list of pvalues after removing the vales greater than the tpv (threshold)
	filelist.sort()
	for f in filelist :
		if re.search("TTc*",f):
			tomtomfile = path+"/"+f + "/tomtom.txt";
			openfile = open(tomtomfile,"r")
			in_txt = csv.reader(openfile, delimiter = '\t')
			for row in in_txt:
				seed = row[0]
				#print seed + "\n"
				if re.search("Target*",row[1]) :
					continue
				matches.append(row[1])
				pvalue.append(row[3])
				#print str(len(mylist)) + "\n"
		
			openfile.close()
		
			#print "length of the initial matches list " + f +"  "+ str(len(matches))
		
	
			if len(matches) > 0 : 

				temp = removeThreshold(pvalue)
				matches = removeMatches(matches, temp)
		
			

			#print matches # list of motifs that are having p-value <=0.0001
			#print temp #list of pvalues
			print "-------------------------------------------------------------\n"
			
	return matches

def moveRedundantMotifs(motifs,iteration):
	"""
	moves the RedundantMotifs from indPwmfiles folder to other folder so that they are not included in the next iteration	
	"""
	print " ---------------------------------------------------------------\n"
	print " no of motifs to move in "+str(iteration)+" iteration : "+ str(len(motifs))
	if(os.path.exists(dirpath+"/Redundant")):
		os.mkdir(dirpath+"/Redundant/iteration_"+str(iteration))
		if(len(motifs) != 0):
			for mn in motifs :
				source = dirpath+"/indPwmfiles/" + mn +".pwm"
				destination = dirpath+"/Redundant/iteration_"+str(iteration) +"/"+ mn +".pwm"
				#print source + "\t" + destination + "\n"
				shutil.move(source,destination)
	else:
		print "no Redundant folder"
	print " moved motifs : "+ str(len(motifs))
	print " ---------------------------------------------------------------\n"
	return

def combineFinalMotifs() :

	"""
	combines the non-redundant motif pwms
	"""
	mlist = os.listdir(dirpath+"/indPwmfiles")
	print mlist
	
	mlist.sort()	
	print len(mlist)
	#os.mkdir(dirpath+"/combinedpwm")
	combinedFile = open(dirpath+"/non_redundant_motifs.pwm",'w')
	combinedFile.write(pwmheader)
	# iterating through all the files in the filelist
	for myfile in mlist :
		openfile = open(dirpath+"/indPwmfiles/"+myfile,'r')
		filecontents = openfile.readlines()
		for line in range(6,len(filecontents)):
			combinedFile.write(filecontents[line])
		openfile.close()
	combinedFile.close()
	return

# function calls
if(os.path.exists(dirpath)) :
	pass
else :
	os.mkdir(dirpath)
for it in range(1,1000):
	
	generateIndPwmFiles() # need to be done only once
	createFolders() # need to be done only once
	
	moveSeeds() # everyiteration
	
	compareMotifs(it) #everyiteration

	callMake(it)

	removeSeeds() # everyiteration

	redundantMotifs = refineTomtom(it)

	moveRedundantMotifs(redundantMotifs,it)

combineFinalMotifs() # creates a combined pwm file.

