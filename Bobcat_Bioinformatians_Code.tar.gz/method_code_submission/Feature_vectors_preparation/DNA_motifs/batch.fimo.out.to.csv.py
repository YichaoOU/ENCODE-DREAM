import os
import glob
import sys


motif_database = sys.argv[1] # motif type: either epiMotifs_2034 or nonredundant_1715
motif_dir = sys.argv[2]
bed_dir = sys.argv[3] # train or ladder regions
cut_dir = sys.argv[4]
motif_list = glob.glob(motif_dir+"/"+motif_database+".split.*.pwm")
fimo_out_list = glob.glob(cut_dir+"/*.cut")
# train_bed_list = glob.glob(bed_dir+"/train_regions.blacklistfiltered.bed.copy.a[a-z]")
train_bed_list = glob.glob(bed_dir+"/ladder_regions.blacklistfiltered.bed.copy.a[a-z]")
for bed in train_bed_list:
	bed_index = bed.split(".")[-1]
	for fimo in fimo_out_list:
		temp = fimo.split(".")
		fimo_bed_index = temp[-7]
		if not fimo_bed_index == bed_index:
			continue
		fimo_motif_index = temp[-4]
		for motif in motif_list:
			motif_file_index = motif.split("/")[-1]
			motif_file_index = motif_file_index.split(".")[-2]
			if not motif_file_index == fimo_motif_index:
				continue
			name_suffix = "epiMotifs_2034.split." + motif_file_index + ".spacesv"
			
			command = "python fimo.out.to.csv.py " + motif + " " + fimo + " " + bed + " " + name_suffix
			print command
			os.system(command)
			continue
	


