# from itertools import izip_longest
# split file "train_regions.blacklistfiltered.bed" by "train_regions.blacklistfiltered.merged.bed.copy.*"


suffix = ["aa","ab","ac","ad","ae","af","ag","ah","ai","aj","ak","al","am","an","ao","ap","aq","ar","as","at","au","av","aw","ax","ay","az"]

merged_region_dict = {}

merged_file_prefix = "train_regions.blacklistfiltered.merged.bed.copy."

def populate_merged_dict():
	
	for s in suffix:
		merged_region_dict[s] = []
		merge_file = merged_file_prefix + s
		with open(merge_file, 'rb') as handler:
			for line in handler:
				line = line.strip().split()
				merged_region_dict[s].append([line[0],int(line[1]),int(line[2])])
	return merged_region_dict
	
populate_merged_dict()

input_train_region_file = "train_regions.blacklistfiltered.bed"
# from multiprocessing import Pool
def get_out_line(line):
	if line == "None":
		return 1
	try:
		line = line.strip().split()
		chr = line[0]
	except:
		return 1
	start = int(line[1])
	end = int(line[2])
	for s in suffix:
		for element in merged_region_dict[s]:
			if not chr == element[0]:
				continue
			if start >= element[1] and end <= element[2]:
				return [s,line]
			else:
				continue
	print "something wrong!"

out_file_list_handle = {}
for s in suffix:
	out_file = input_train_region_file + ".copy." + s
	out_file_list_handle[s] = open(out_file,"wb")	
import time	
count = 0
with open(input_train_region_file) as f:
	for line in f:
		r = get_out_line(line)
		if r == 1:
			continue
		[file_handle,line] = r
		print >>out_file_list_handle[file_handle],"\t".join(line)







