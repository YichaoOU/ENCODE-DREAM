import sys
import glob
def all_motif_features(file1):
	motif_list = []
	with open(file1, 'rb') as handler:
		for line in handler:
			if "MOTIF" in line:
				line = line.strip().split()
				if len(line[1]) > 100:
					motif_list.append(line[1][:100])
				else:
					motif_list.append(line[1])
	return motif_list


pwm_files = [sys.argv[1]]
for pwm in pwm_files:
	motif_list = all_motif_features(pwm)
	f = open(pwm.replace("pwm","")+"motif.list","wb")
	print >>f,"\n".join(motif_list)
	f.close()