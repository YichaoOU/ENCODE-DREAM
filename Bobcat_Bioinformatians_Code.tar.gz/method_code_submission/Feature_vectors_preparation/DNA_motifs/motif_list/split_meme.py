import sys
pwm = sys.argv[1]


split = 50
header = """
MEME version 4.4
ALPHABET= ACGT
strands: + -
Background letter frequencies:
A 0.25000 C 0.25000 G 0.25000 T 0.25000
"""

number = 0
out_file = pwm.replace(".pwm","")+".split.number.pwm"
count = 0
out = open(out_file.replace("number",str(number)),"wb")
print >>out,header
for line in open(pwm).readlines()[6:]:
	if "MOTIF" in line:
		count += 1
		if count > split:
			number += 1
			count = 1
			out = open(out_file.replace("number",str(number)),"wb")
			print >>out,header

		print >>out,line.strip()
		
	else:
		print >>out,line.strip()







