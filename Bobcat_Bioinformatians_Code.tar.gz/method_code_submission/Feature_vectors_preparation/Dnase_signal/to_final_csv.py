import glob
# from itertools import izip_longest
# from multiprocessing import Pool
import sys
bed_add_number_file_dir = sys.argv[1]
Dnase_signal_out_dir = sys.argv[2]
bed_file_list = [bed_add_number_file_dir+"/ladder_regions.blacklistfiltered.bed.add.number.bed"]
dnase_file_list = glob.glob(Dnase_signal_out_dir+"/*.Dnase.out")


def bed_to_list(file):
	bed_dict = {}
	with open(file, 'rb') as handler:
		for line in handler:
			line = line.strip().split()
			name = line[0]+":"+line[1]+"-"+line[2]
			bed_dict[line[-1]]=name
	return bed_dict
			
def get_out_line(i):
	line = next_n_lines[i]
	# print line
	if line == "None":
		return 1
	try:
		line = line.strip().split()
		
	except:
		return 1
	# if i%10000 == 0:
		# print i
	if not len(line) == 6:
		return 1
	key = line[0]
	name = bed_dict[key]
	return [name,line[-3],line[-2],line[-1]]

def get_out_line2(line):
	# global bed_dict
	# line = next_n_lines[i]
	# print line
	# if line == "None":
		# return 1
	# try:
	line = line.strip().split()
		
	# except:
		# return 1
	# if i%10000 == 0:
		# print i
	# if not len(line) == 6:
		# return 1
	key = line[0]
	name = bed_dict[key]
	return [name,line[-3],line[-2],line[-1]]

				
			
			
for bed in bed_file_list:
	# key1 = bed.split("/")[-1]
	# key1 = key1.split(".")[-4]
	# global bed_dict
	bed_dict = bed_to_list(bed)
	print "bed finished"
	for dnase in dnase_file_list:
		# key2 = dnase.split("/")[-1]
		# key2 = key2.split(".")[4]
		# if not key1 == key2:
			# continue
		out_file_name = dnase+".final.out"
		out_file = open(out_file_name,"wb")
		with open(dnase) as f:
			for line in f:
				results = get_out_line2(line)
				# print results
				if results == 1:
					continue
				print >>out_file,",".join(results)
		out_file.close()
		print dnase,"finished"	
			