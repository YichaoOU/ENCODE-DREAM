import numpy as np
import pandas as pd
import sys
from sklearn.ensemble import RandomForestClassifier as RFC
from sklearn import svm
from sklearn import datasets
from sklearn.cross_validation import StratifiedKFold
from sklearn.cross_validation import KFold
from sklearn.grid_search import GridSearchCV
from sklearn.metrics import classification_report
from sklearn.metrics import precision_score
from sklearn.metrics import accuracy_score
from sklearn.metrics import recall_score
from sklearn.metrics import roc_curve
from sklearn.metrics import auc
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier as DTC
from sklearn.metrics import average_precision_score
from sklearn.externals import joblib
import glob
TF = sys.argv[1]
cell = sys.argv[2]
TF_cell = TF+"."+cell
testing_file_list = glob.glob("./"+TF_cell+"/*")

model_file = "../Final_TF_all_features_csv/"+TF+"/"+TF+".final.model"
import os

rf_clf = joblib.load(model_file)
os.mkdir("../final_prediction2/"+TF_cell)
for testing_file in testing_file_list:
	print testing_file
	file_index = testing_file.split("/")[-1]


	data1 = pd.read_csv(testing_file,delimiter = ",",header=None,nrows=1)
	number_row,number_column = data1.shape
	data2 = pd.read_csv(testing_file,delimiter = ",",header=None,usecols=[0])
	data3 = pd.read_csv(testing_file,delimiter = ",",header=None,usecols=range(1,number_column))
	# data = pd.read_csv(testing_file,delimiter = ",",header=None)
	[a,b] = data3.shape
	# print a,b
	test = data3.values
	# chr_location = list(data.values[:,0])
	# print test.shape
	print "begin prediction"
	y_pred = rf_clf.predict_proba(test)
	print "finish prediction "
	del test
	del data3
	log_out_file = "../final_prediction2/"+TF_cell+"/"+file_index+".prediction"
	log = open(log_out_file,"wb")
	probility = map(lambda x:x[1],y_pred)
	# out_lines = map(lambda x:str(chr_location[x])+" "+str(probility[x]),range(a))
	out_lines = map(lambda x:str(data2[0][x])+" "+str(probility[x]),range(a))
	# print y_true,y_pred
	print >>log,"\n".join(out_lines)
	log.close()
