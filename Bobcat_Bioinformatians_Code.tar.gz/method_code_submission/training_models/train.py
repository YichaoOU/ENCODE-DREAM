import numpy as np
import pandas as pd
import sys
from sklearn.ensemble import RandomForestClassifier as RFC
from sklearn import svm
from sklearn import datasets
from sklearn.cross_validation import StratifiedKFold
from sklearn.cross_validation import KFold
from sklearn.grid_search import GridSearchCV
from sklearn.metrics import classification_report
from sklearn.metrics import precision_score
from sklearn.metrics import accuracy_score
from sklearn.metrics import recall_score
from sklearn.metrics import roc_curve
from sklearn.metrics import auc
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier as DTC
from sklearn.metrics import average_precision_score
from sklearn.externals import joblib

training_file = sys.argv[1]
TF = training_file.split(".")[0]
print TF

data1 = pd.read_csv(training_file,delimiter = ",",header=None,nrows=1)
number_row,number_column = data1.shape
data2 = pd.read_csv(training_file,delimiter = ",",header=None,usecols=range(1,number_column-1))
data3 = pd.read_csv(training_file,delimiter = ",",header=None,usecols=[number_column-1])
print "finish reading data"
X_train = data2.values

Y_train = list(data3.values[:,0])
# Y_train = data3.single_column.values

print "begin classification"
### this is the default parameters
# rf_clf = RFC(n_estimators=150,n_jobs=-1,class_weight ={0:0.01,1:0.99})
### this is the tuned parameters, this best fits CTCF, EGR1, where we have best scores.
rf_clf = RFC(n_estimators=100,n_jobs=-1,min_samples_split=1,min_samples_leaf=2,min_weight_fraction_leaf=0.01,max_leaf_nodes=1000,max_features=None) # ATF2
# rf_clf.fit(X_train, Y_train)
rf_clf.fit(X_train, Y_train)
# rf_clf.fit(X_train, Y_train.values.ravel())
import os
try:
	os.mkdir(TF)
	out_model = TF+"/"+TF+".final.model"
	joblib.dump(rf_clf, out_model)
except:
	out_model = TF+".final.model"
	joblib.dump(rf_clf, out_model)

