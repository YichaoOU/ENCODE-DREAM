import glob
import sys
import os


tf_cell = sys.argv[1]
template_file = "/home/working/dream_encode/annotations/test_regions.blacklistfiltered.bed"
# template_file = "/home/working/dream_encode/annotations/ladder_regions.blacklistfiltered.bed"
template_interval_list = []
template_dict = {}

def parse_template_file(template_file):
	with open(template_file, 'rb') as handler:
		for line in handler:
			line = line.strip().split()
			sequence_name = line[0]+":"+line[1]+"-"+line[2]
			template_interval_list.append(sequence_name)
			
	
def parse_prediction_file(prediction_file):
	print prediction_file
	with open(prediction_file, 'rb') as handler:
		for line in handler:
			line = line.strip().split()
			sequence_name = line[0]
			template_dict[sequence_name] = line[1]
parse_template_file(template_file)

print tf_cell
# for sequence_name in template_interval_list:
	# template_dict[sequence_name] = "0.0"
prediction_dir = "/home/working/my_second_drive/dream_challenge/final_prediction/" + tf_cell + "/"

prediction_file_list = glob.glob(prediction_dir+tf_cell+"*.prediction*")
# print prediction_dir+tf_cell+".prediction*"
# print prediction_file_list
map(lambda x:parse_prediction_file(x),prediction_file_list)

os.mkdir(tf_cell)
out_file = "./" + tf_cell + "/F." + tf_cell + ".tab"
out = open(out_file,"wb")
for sequence_name in template_interval_list:
	prob = template_dict[sequence_name]
	first = sequence_name.split(":")
	second = first[1].split("-")
	chr = first[0]
	start = second[0]
	end = second[1]
	print >>out,"\t".join([chr,start,end,prob])


# os.system("gzip "+out_file)





